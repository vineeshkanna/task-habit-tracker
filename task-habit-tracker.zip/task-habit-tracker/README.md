# Tally — Personal Task & Habit Tracker

A full-stack productivity app that combines task management with daily habit streaks and weekly progress analytics.

**Stack:** React (Vite), Tailwind CSS, Axios, Node.js, Express.js, PostgreSQL / MySQL, Prisma ORM, JWT, bcrypt, Zod

## Features
- Sign up / log in with bcrypt-hashed passwords and JWT-protected routes
- Task CRUD with title, description, category, priority (Low/Medium/High), due date
- Filtering by status, priority and deadline (overdue / today / this week), plus search and sorting
- Daily habit tracker with a streak-counter algorithm and a 7-day consistency strip
- Analytics dashboard: weekly task completion, habit fulfillment %, daily activity

## Project structure
```
task-habit-tracker/
├── backend/
│   ├── prisma/schema.prisma
│   └── src/ (config, controllers, middleware, routes, utils, app.js, server.js)
└── frontend/
    └── src/ (api, components, context, pages, App.jsx, main.jsx)
```

## Getting started

### 1. Backend
```bash
cd backend
npm install
cp .env.example .env        # set DATABASE_URL and JWT_SECRET
npx prisma migrate dev --name init
npm run dev                 # http://localhost:5000
```
Using MySQL? Change `provider` to `"mysql"` in `prisma/schema.prisma`, update `DATABASE_URL`, and remove `mode: 'insensitive'` in `task.controller.js` (MySQL is case-insensitive by default).

### 2. Frontend
```bash
cd frontend
npm install
cp .env.example .env
npm run dev                 # http://localhost:5173
```

## REST API
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Create an account |
| POST | `/api/auth/login` | Log in and receive a JWT |
| GET | `/api/auth/me` | Current user |
| GET | `/api/tasks` | List tasks. Query: `status`, `priority`, `deadline`, `category`, `search`, `sort` |
| POST | `/api/tasks` | Create a task |
| PUT | `/api/tasks/:id` | Update a task |
| DELETE | `/api/tasks/:id` | Delete a task |
| GET | `/api/habits` | List habits with streaks |
| POST | `/api/habits` | Create a habit |
| POST | `/api/habits/:id/toggle` | Toggle a day and update the streak |
| DELETE | `/api/habits/:id` | Delete a habit |
| GET | `/api/analytics/summary` | Weekly analytics |

Protected routes need `Authorization: Bearer <token>`.

## Design notes
- **Streaks:** each completed day is a `HabitLog` row. The streak counts consecutive days ending today, or yesterday if today isn't done yet.
- **Timezones:** the client sends its local date so streaks follow the user's day, not the server's.
- **Security:** bcrypt (12 rounds), Helmet, CORS allow-list, rate-limited auth routes, Zod validation, per-user data scoping.
