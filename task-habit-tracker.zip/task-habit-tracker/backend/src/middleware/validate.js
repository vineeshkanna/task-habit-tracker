/** Validates req.body / req.query against a zod schema. */
const validate = (schema, source = 'body') => (req, res, next) => {
  const result = schema.safeParse(req[source]);
  if (!result.success) {
    return res.status(400).json({
      message: 'Validation failed',
      errors: result.error.issues.map((i) => ({
        field: i.path.join('.'),
        message: i.message,
      })),
    });
  }
  // Express 4 allows reassigning req.query; keep parsed values
  req[source] = result.data;
  next();
};

module.exports = validate;
