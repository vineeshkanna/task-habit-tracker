const router = require('express').Router();
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const c = require('../controllers/task.controller');

router.use(authenticate);

router.get('/', validate(c.listQuerySchema, 'query'), c.getTasks);
router.post('/', validate(c.createTaskSchema), c.createTask);
router.put('/:id', validate(c.updateTaskSchema), c.updateTask);
router.delete('/:id', c.deleteTask);

module.exports = router;
