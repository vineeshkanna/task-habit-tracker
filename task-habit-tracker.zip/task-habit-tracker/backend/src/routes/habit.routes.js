const router = require('express').Router();
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const c = require('../controllers/habit.controller');

router.use(authenticate);

router.get('/', validate(c.listQuerySchema, 'query'), c.getHabits);
router.post('/', validate(c.habitSchema), c.createHabit);
router.delete('/:id', c.deleteHabit);
router.post('/:id/toggle', validate(c.toggleSchema), c.toggleHabit);

module.exports = router;
