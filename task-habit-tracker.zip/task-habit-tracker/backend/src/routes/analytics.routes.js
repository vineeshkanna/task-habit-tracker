const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const { getSummary } = require('../controllers/analytics.controller');

router.get('/summary', authenticate, getSummary);

module.exports = router;
