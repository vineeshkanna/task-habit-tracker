const { z } = require('zod');
const prisma = require('../config/prisma');
const { fromKey, todayKey, lastNDays } = require('../utils/dates');
const { computeStreak } = require('../utils/streak');

const dateKey = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD');

const habitSchema = z.object({
  title: z.string().trim().min(1, 'Title is required').max(100),
});

// The client sends its own local date so "today" matches the user's timezone.
const toggleSchema = z.object({ date: dateKey.optional() });
const listQuerySchema = z.object({ date: dateKey.optional() });

const keysOf = (logs) => logs.map((l) => l.date.toISOString().slice(0, 10));

function shape(habit, today) {
  const keys = keysOf(habit.logs);
  return {
    id: habit.id,
    title: habit.title,
    streak: computeStreak(keys, today),
    completedToday: keys.includes(today),
    last7Days: lastNDays(today, 7).map((d) => ({ date: d, done: keys.includes(d) })),
  };
}

async function getHabits(req, res, next) {
  try {
    const today = req.query.date || todayKey();
    const habits = await prisma.habit.findMany({
      where: { userId: req.user.id },
      include: { logs: true },
      orderBy: { createdAt: 'asc' },
    });
    res.json({ habits: habits.map((h) => shape(h, today)) });
  } catch (err) {
    next(err);
  }
}

async function createHabit(req, res, next) {
  try {
    const habit = await prisma.habit.create({
      data: { title: req.body.title, userId: req.user.id },
      include: { logs: true },
    });
    res.status(201).json({ habit: shape(habit, todayKey()) });
  } catch (err) {
    next(err);
  }
}

async function deleteHabit(req, res, next) {
  try {
    const id = Number(req.params.id);
    const result = await prisma.habit.deleteMany({ where: { id, userId: req.user.id } });
    if (result.count === 0) return res.status(404).json({ message: 'Habit not found' });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

/** POST /api/habits/:id/toggle — toggle a day and refresh streak metrics. */
async function toggleHabit(req, res, next) {
  try {
    const id = Number(req.params.id);
    const today = req.body.date || todayKey();

    const owned = await prisma.habit.findFirst({ where: { id, userId: req.user.id } });
    if (!owned) return res.status(404).json({ message: 'Habit not found' });

    const key = { habitId_date: { habitId: id, date: fromKey(today) } };
    const existing = await prisma.habitLog.findUnique({ where: key });

    if (existing) await prisma.habitLog.delete({ where: key });
    else await prisma.habitLog.create({ data: { habitId: id, date: fromKey(today) } });

    const logs = await prisma.habitLog.findMany({ where: { habitId: id } });
    const streak = computeStreak(keysOf(logs), today);

    const habit = await prisma.habit.update({
      where: { id },
      data: { streak, completed: !existing },
      include: { logs: true },
    });
    res.json({ habit: shape(habit, today) });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getHabits, createHabit, deleteHabit, toggleHabit,
  habitSchema, toggleSchema, listQuerySchema,
};
