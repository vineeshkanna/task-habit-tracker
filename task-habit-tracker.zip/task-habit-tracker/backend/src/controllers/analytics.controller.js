const prisma = require('../config/prisma');
const { fromKey, todayKey, lastNDays } = require('../utils/dates');

/** GET /api/analytics/summary — weekly task completion + habit fulfillment. */
async function getSummary(req, res, next) {
  try {
    const today = /^\d{4}-\d{2}-\d{2}$/.test(req.query.date || '') ? req.query.date : todayKey();
    const days = lastNDays(today, 7);
    const weekStart = fromKey(days[0]);
    const userId = req.user.id;

    const [tasks, habits, logs] = await Promise.all([
      prisma.task.findMany({ where: { userId } }),
      prisma.habit.findMany({ where: { userId }, select: { id: true } }),
      prisma.habitLog.findMany({
        where: { habit: { userId }, date: { gte: weekStart, lte: fromKey(today) } },
      }),
    ]);

    const byStatus = { PENDING: 0, IN_PROGRESS: 0, COMPLETED: 0 };
    tasks.forEach((t) => { byStatus[t.status] += 1; });

    const completedThisWeek = tasks.filter((t) => t.completedAt && t.completedAt >= weekStart).length;
    const overdue = tasks.filter(
      (t) => t.status !== 'COMPLETED' && t.dueDate && t.dueDate < fromKey(today)
    ).length;
    const taskCompletionRate = tasks.length
      ? Math.round((byStatus.COMPLETED / tasks.length) * 100)
      : 0;

    // Habit fulfillment = completed check-ins / possible check-ins over 7 days
    const possible = habits.length * 7;
    const habitFulfillment = possible ? Math.round((logs.length / possible) * 100) : 0;

    const daily = days.map((d) => ({
      date: d,
      habitsDone: logs.filter((l) => l.date.toISOString().slice(0, 10) === d).length,
      tasksCompleted: tasks.filter(
        (t) => t.completedAt && t.completedAt.toISOString().slice(0, 10) === d
      ).length,
    }));

    res.json({
      tasks: { total: tasks.length, byStatus, completedThisWeek, overdue, taskCompletionRate },
      habits: { total: habits.length, habitFulfillment },
      daily,
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { getSummary };
