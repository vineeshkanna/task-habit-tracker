const { z } = require('zod');
const prisma = require('../config/prisma');

const STATUS = ['PENDING', 'IN_PROGRESS', 'COMPLETED'];
const PRIORITY = ['LOW', 'MEDIUM', 'HIGH'];

const taskBody = z.object({
  title: z.string().trim().min(1, 'Title is required').max(150),
  description: z.string().trim().max(1000).nullish(),
  category: z.string().trim().min(1).max(50).optional(),
  status: z.enum(STATUS).optional(),
  priority: z.enum(PRIORITY).optional(),
  dueDate: z.coerce.date().nullish(),
});

const createTaskSchema = taskBody;
const updateTaskSchema = taskBody.partial();

const listQuerySchema = z.object({
  status: z.enum(STATUS).optional(),
  priority: z.enum(PRIORITY).optional(),
  category: z.string().optional(),
  search: z.string().optional(),
  // deadline=overdue | today | week (approaching deadlines)
  deadline: z.enum(['overdue', 'today', 'week']).optional(),
  sort: z.enum(['dueDate', 'priority', 'createdAt']).default('createdAt'),
});

const PRIORITY_RANK = { HIGH: 0, MEDIUM: 1, LOW: 2 };
const DAY = 24 * 60 * 60 * 1000;

function deadlineFilter(kind) {
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  if (kind === 'overdue') return { lt: startOfDay };
  if (kind === 'today') return { gte: startOfDay, lt: new Date(startOfDay.getTime() + DAY) };
  return { gte: startOfDay, lt: new Date(startOfDay.getTime() + 7 * DAY) };
}

async function getTasks(req, res, next) {
  try {
    const { status, priority, category, search, deadline, sort } = req.query;

    const where = { userId: req.user.id };
    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (category) where.category = category;
    if (search) where.title = { contains: search, mode: 'insensitive' };
    if (deadline) {
      where.dueDate = deadlineFilter(deadline);
      if (deadline === 'overdue' && !status) where.status = { not: 'COMPLETED' };
    }

    let tasks = await prisma.task.findMany({
      where,
      orderBy: sort === 'dueDate' ? { dueDate: 'asc' } : { createdAt: 'desc' },
    });

    if (sort === 'priority') {
      tasks = tasks.sort((a, b) => PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority]);
    }
    res.json({ tasks });
  } catch (err) {
    next(err);
  }
}

async function createTask(req, res, next) {
  try {
    const data = { ...req.body, userId: req.user.id };
    if (data.status === 'COMPLETED') data.completedAt = new Date();
    const task = await prisma.task.create({ data });
    res.status(201).json({ task });
  } catch (err) {
    next(err);
  }
}

async function updateTask(req, res, next) {
  try {
    const id = Number(req.params.id);
    const existing = await prisma.task.findFirst({ where: { id, userId: req.user.id } });
    if (!existing) return res.status(404).json({ message: 'Task not found' });

    const data = { ...req.body };
    if (data.status && data.status !== existing.status) {
      data.completedAt = data.status === 'COMPLETED' ? new Date() : null;
    }
    const task = await prisma.task.update({ where: { id }, data });
    res.json({ task });
  } catch (err) {
    next(err);
  }
}

async function deleteTask(req, res, next) {
  try {
    const id = Number(req.params.id);
    const result = await prisma.task.deleteMany({ where: { id, userId: req.user.id } });
    if (result.count === 0) return res.status(404).json({ message: 'Task not found' });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getTasks, createTask, updateTask, deleteTask,
  createTaskSchema, updateTaskSchema, listQuerySchema,
};
