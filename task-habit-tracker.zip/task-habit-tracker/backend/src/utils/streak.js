const { addDays } = require('./dates');

/**
 * Streak counter algorithm.
 * Counts consecutive completed days ending on `todayKey`.
 * If today is not done yet, the streak is still alive when yesterday was
 * completed (the user has until the end of today to continue it).
 *
 * @param {string[]} dateKeys - completed days as "YYYY-MM-DD"
 * @param {string} todayKey   - the user's current calendar day
 * @returns {number}
 */
function computeStreak(dateKeys, todayKey) {
  const done = new Set(dateKeys);
  let cursor = done.has(todayKey) ? todayKey : addDays(todayKey, -1);
  let streak = 0;

  while (done.has(cursor)) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

module.exports = { computeStreak };
