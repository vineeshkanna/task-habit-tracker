// Calendar-day helpers. All days are handled as "YYYY-MM-DD" strings
// and stored as 00:00 UTC so a day never shifts with server timezone.

const DAY_MS = 24 * 60 * 60 * 1000;

const toKey = (date) => new Date(date).toISOString().slice(0, 10);

const fromKey = (key) => new Date(`${key}T00:00:00.000Z`);

const todayKey = () => toKey(new Date());

const addDays = (key, n) => toKey(fromKey(key).getTime() + n * DAY_MS);

const lastNDays = (endKey, n) =>
  Array.from({ length: n }, (_, i) => addDays(endKey, -(n - 1 - i)));

module.exports = { toKey, fromKey, todayKey, addDays, lastNDays };
