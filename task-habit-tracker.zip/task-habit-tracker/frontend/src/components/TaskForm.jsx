import { useState } from 'react';

const empty = { title: '', description: '', category: 'General', priority: 'MEDIUM', dueDate: '' };

const toInputDate = (d) => (d ? new Date(d).toISOString().slice(0, 10) : '');

export default function TaskForm({ initial, onSubmit, onCancel }) {
  const [form, setForm] = useState(
    initial ? { ...empty, ...initial, description: initial.description || '', dueDate: toInputDate(initial.dueDate) } : empty
  );
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.title.trim()) return setError('Give the task a title.');
    setSaving(true);
    setError('');
    try {
      await onSubmit({
        title: form.title,
        description: form.description || null,
        category: form.category || 'General',
        priority: form.priority,
        dueDate: form.dueDate || null,
      });
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="panel space-y-4 p-5">
      <div>
        <label className="label" htmlFor="title">Title</label>
        <input id="title" className="field" value={form.title} onChange={set('title')} placeholder="Finish API documentation" autoFocus />
      </div>
      <div>
        <label className="label" htmlFor="description">Description</label>
        <textarea id="description" rows={2} className="field" value={form.description} onChange={set('description')} />
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <div>
          <label className="label" htmlFor="category">Category</label>
          <input id="category" className="field" value={form.category} onChange={set('category')} />
        </div>
        <div>
          <label className="label" htmlFor="priority">Priority</label>
          <select id="priority" className="field" value={form.priority} onChange={set('priority')}>
            <option value="LOW">Low</option>
            <option value="MEDIUM">Medium</option>
            <option value="HIGH">High</option>
          </select>
        </div>
        <div>
          <label className="label" htmlFor="dueDate">Due date</label>
          <input id="dueDate" type="date" className="field" value={form.dueDate} onChange={set('dueDate')} />
        </div>
      </div>
      {error && <p role="alert" className="text-sm text-alert">{error}</p>}
      <div className="flex justify-end gap-2">
        <button type="button" className="btn-ghost" onClick={onCancel}>Cancel</button>
        <button className="btn-primary" disabled={saving}>{initial ? 'Save changes' : 'Add task'}</button>
      </div>
    </form>
  );
}
