import { NavLink, Outlet } from 'react-router-dom';
import { LayoutDashboard, ListChecks, Flame, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';

const links = [
  { to: '/', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/tasks', label: 'Tasks', icon: ListChecks },
  { to: '/habits', label: 'Habits', icon: Flame },
];

export default function Layout() {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-card">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-3">
          <span className="font-display text-xl font-bold text-pine">Tally</span>

          <nav className="flex gap-1" aria-label="Main">
            {links.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    isActive ? 'bg-pine-tint text-pine-dark' : 'text-ink-soft hover:bg-paper'
                  }`
                }
              >
                <Icon size={16} aria-hidden />
                <span className="hidden sm:inline">{label}</span>
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <span className="hidden text-sm text-ink-soft md:inline">{user?.name}</span>
            <button onClick={logout} className="btn-ghost px-3" aria-label="Log out">
              <LogOut size={16} aria-hidden />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
}
