import { Check, Flame, Trash2 } from 'lucide-react';

const dayLetter = (key) =>
  new Date(`${key}T12:00:00`).toLocaleDateString(undefined, { weekday: 'narrow' });

/** The 7-day strip is the centerpiece: each dot is one day of consistency. */
export default function HabitCard({ habit, onToggle, onDelete }) {
  return (
    <li className="panel p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold">{habit.title}</h3>
          <p className="mt-1 flex items-center gap-1 text-sm text-ink-soft">
            <Flame size={15} className={habit.streak ? 'text-ember' : 'text-ink-faint'} aria-hidden />
            {habit.streak} day{habit.streak === 1 ? '' : 's'} in a row
          </p>
        </div>
        <button className="rounded-lg p-2 text-ink-faint hover:bg-alert/10 hover:text-alert" onClick={() => onDelete(habit)} aria-label={`Delete ${habit.title}`}>
          <Trash2 size={15} />
        </button>
      </div>

      <div className="mt-5 flex items-end justify-between gap-4">
        <ol className="flex gap-2" aria-label="Last 7 days">
          {habit.last7Days.map((d) => (
            <li key={d.date} className="flex flex-col items-center gap-1">
              <span
                className={`h-6 w-6 rounded-full ${d.done ? 'bg-pine' : 'border border-line bg-paper'}`}
                title={d.date}
              />
              <span className="text-[11px] text-ink-faint">{dayLetter(d.date)}</span>
            </li>
          ))}
        </ol>

        <button
          onClick={() => onToggle(habit)}
          className={habit.completedToday ? 'btn bg-pine-tint text-pine-dark' : 'btn-primary'}
          aria-pressed={habit.completedToday}
        >
          <Check size={16} aria-hidden />
          {habit.completedToday ? 'Done today' : 'Mark done'}
        </button>
      </div>
    </li>
  );
}
