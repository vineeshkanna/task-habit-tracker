import { CalendarDays, Pencil, Trash2 } from 'lucide-react';

const PRIORITY_STYLE = {
  HIGH: 'bg-alert/10 text-alert',
  MEDIUM: 'bg-ember-tint text-ember',
  LOW: 'bg-pine-tint text-pine-dark',
};
const STATUS_LABEL = { PENDING: 'Pending', IN_PROGRESS: 'In progress', COMPLETED: 'Completed' };

export default function TaskCard({ task, onStatusChange, onEdit, onDelete }) {
  const due = task.dueDate ? new Date(task.dueDate) : null;
  const overdue = due && task.status !== 'COMPLETED' && due < new Date(new Date().setHours(0, 0, 0, 0));
  const done = task.status === 'COMPLETED';

  return (
    <li className="panel flex items-start gap-4 p-4">
      <input
        type="checkbox"
        checked={done}
        onChange={() => onStatusChange(task, done ? 'PENDING' : 'COMPLETED')}
        className="mt-1 h-5 w-5 accent-pine"
        aria-label={`Mark "${task.title}" ${done ? 'not done' : 'done'}`}
      />

      <div className="min-w-0 flex-1">
        <p className={`font-medium ${done ? 'text-ink-faint line-through' : ''}`}>{task.title}</p>
        {task.description && <p className="mt-0.5 text-sm text-ink-soft">{task.description}</p>}

        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
          <span className={`rounded-full px-2 py-0.5 font-medium ${PRIORITY_STYLE[task.priority]}`}>
            {task.priority.charAt(0) + task.priority.slice(1).toLowerCase()}
          </span>
          <span className="rounded-full bg-paper px-2 py-0.5 text-ink-soft">{task.category}</span>
          {due && (
            <span className={`flex items-center gap-1 ${overdue ? 'font-semibold text-alert' : 'text-ink-soft'}`}>
              <CalendarDays size={13} aria-hidden />
              {overdue ? 'Overdue · ' : ''}
              {due.toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1">
        <select
          value={task.status}
          onChange={(e) => onStatusChange(task, e.target.value)}
          className="rounded-lg border border-line bg-card px-2 py-1 text-xs"
          aria-label="Task status"
        >
          {Object.entries(STATUS_LABEL).map(([v, l]) => (
            <option key={v} value={v}>{l}</option>
          ))}
        </select>
        <button className="rounded-lg p-2 text-ink-soft hover:bg-paper" onClick={() => onEdit(task)} aria-label="Edit task">
          <Pencil size={15} />
        </button>
        <button className="rounded-lg p-2 text-alert hover:bg-alert/10" onClick={() => onDelete(task)} aria-label="Delete task">
          <Trash2 size={15} />
        </button>
      </div>
    </li>
  );
}
