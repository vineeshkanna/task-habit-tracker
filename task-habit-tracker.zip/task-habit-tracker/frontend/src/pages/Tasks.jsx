import { useCallback, useEffect, useState } from 'react';
import { Plus, Search } from 'lucide-react';
import api, { errorMessage } from '../api/client.js';
import TaskCard from '../components/TaskCard.jsx';
import TaskForm from '../components/TaskForm.jsx';

const initialFilters = { status: '', priority: '', deadline: '', search: '', sort: 'createdAt' };

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [filters, setFilters] = useState(initialFilters);
  const [editing, setEditing] = useState(null); // null | 'new' | task
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v));
      const { data } = await api.get('/tasks', { params });
      setTasks(data.tasks);
      setError('');
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [filters]);

  // Debounce so typing in search doesn't fire a request per keystroke
  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [load]);

  const setFilter = (key) => (e) => setFilters({ ...filters, [key]: e.target.value });

  async function save(values) {
    try {
      if (editing === 'new') await api.post('/tasks', values);
      else await api.put(`/tasks/${editing.id}`, values);
    } catch (err) {
      throw new Error(errorMessage(err));
    }
    setEditing(null);
    load();
  }

  async function changeStatus(task, status) {
    // Optimistic update so the checkbox responds instantly
    setTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, status } : t)));
    try {
      await api.put(`/tasks/${task.id}`, { status });
    } catch (err) {
      setError(errorMessage(err));
    }
    load();
  }

  async function remove(task) {
    if (!window.confirm(`Delete "${task.title}"?`)) return;
    try {
      await api.delete(`/tasks/${task.id}`);
      setTasks((prev) => prev.filter((t) => t.id !== task.id));
    } catch (err) {
      setError(errorMessage(err));
    }
  }

  const filtered = Object.entries(filters).some(([k, v]) => v && !(k === 'sort' && v === 'createdAt'));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Tasks</h1>
        {!editing && (
          <button className="btn-primary" onClick={() => setEditing('new')}>
            <Plus size={16} aria-hidden /> New task
          </button>
        )}
      </div>

      {editing && (
        <TaskForm
          initial={editing === 'new' ? null : editing}
          onSubmit={save}
          onCancel={() => setEditing(null)}
        />
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <div className="relative lg:col-span-2">
          <Search size={15} className="absolute left-3 top-3 text-ink-faint" aria-hidden />
          <input className="field pl-9" placeholder="Search tasks" value={filters.search} onChange={setFilter('search')} aria-label="Search tasks" />
        </div>
        <select className="field" value={filters.status} onChange={setFilter('status')} aria-label="Filter by status">
          <option value="">Any status</option>
          <option value="PENDING">Pending</option>
          <option value="IN_PROGRESS">In progress</option>
          <option value="COMPLETED">Completed</option>
        </select>
        <select className="field" value={filters.priority} onChange={setFilter('priority')} aria-label="Filter by priority">
          <option value="">Any priority</option>
          <option value="HIGH">High</option>
          <option value="MEDIUM">Medium</option>
          <option value="LOW">Low</option>
        </select>
        <select className="field" value={filters.deadline} onChange={setFilter('deadline')} aria-label="Filter by deadline">
          <option value="">Any deadline</option>
          <option value="overdue">Overdue</option>
          <option value="today">Due today</option>
          <option value="week">Due this week</option>
        </select>
      </div>

      <div className="flex items-center justify-between text-sm text-ink-soft">
        <label className="flex items-center gap-2">
          Sort by
          <select className="rounded-lg border border-line bg-card px-2 py-1" value={filters.sort} onChange={setFilter('sort')}>
            <option value="createdAt">Newest</option>
            <option value="dueDate">Due date</option>
            <option value="priority">Priority</option>
          </select>
        </label>
        {filtered && (
          <button className="font-semibold text-pine underline" onClick={() => setFilters(initialFilters)}>Clear filters</button>
        )}
      </div>

      {error && <p role="alert" className="text-alert">{error}</p>}

      {loading ? (
        <p className="text-ink-soft">Loading…</p>
      ) : tasks.length === 0 ? (
        <p className="panel p-6 text-ink-soft">
          {filtered ? 'No tasks match these filters.' : 'No tasks yet. Add your first one to get started.'}
        </p>
      ) : (
        <ul className="space-y-3">
          {tasks.map((t) => (
            <TaskCard key={t.id} task={t} onStatusChange={changeStatus} onEdit={setEditing} onDelete={remove} />
          ))}
        </ul>
      )}
    </div>
  );
}
