import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { errorMessage } from '../api/client.js';

export default function AuthPage({ mode }) {
  const isRegister = mode === 'register';
  const { user, login, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (isRegister && form.password.length < 8) return setError('Password must be at least 8 characters.');
    setBusy(true);
    try {
      if (isRegister) await register(form);
      else await login({ email: form.email, password: form.password });
      navigate('/');
    } catch (err) {
      setError(errorMessage(err));
      setBusy(false);
    }
  }

  return (
    <div className="grid min-h-screen md:grid-cols-2">
      <section className="hidden flex-col justify-between bg-pine p-12 text-white md:flex">
        <span className="font-display text-2xl font-bold">Tally</span>
        <div>
          <p className="font-display text-4xl font-bold leading-tight">
            Finish what's due.<br />Keep what you started.
          </p>
          <p className="mt-4 max-w-sm text-white/75">
            Tasks with deadlines and habits with streaks, in one place.
          </p>
        </div>
        <div className="flex gap-2" aria-hidden>
          {[1, 1, 1, 0, 1, 1, 1].map((on, i) => (
            <span key={i} className={`h-6 w-6 rounded-full ${on ? 'bg-white' : 'border border-white/40'}`} />
          ))}
        </div>
      </section>

      <section className="flex items-center justify-center p-6">
        <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
          <h1 className="text-3xl font-bold">{isRegister ? 'Create your account' : 'Log in'}</h1>

          {isRegister && (
            <div>
              <label className="label" htmlFor="name">Name</label>
              <input id="name" className="field" value={form.name} onChange={set('name')} required />
            </div>
          )}
          <div>
            <label className="label" htmlFor="email">Email</label>
            <input id="email" type="email" className="field" value={form.email} onChange={set('email')} required />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" type="password" className="field" value={form.password} onChange={set('password')} required />
          </div>

          {error && <p role="alert" className="text-sm text-alert">{error}</p>}

          <button className="btn-primary w-full" disabled={busy}>
            {isRegister ? 'Create account' : 'Log in'}
          </button>

          <p className="text-sm text-ink-soft">
            {isRegister ? 'Already have an account? ' : 'New here? '}
            <Link className="font-semibold text-pine underline" to={isRegister ? '/login' : '/register'}>
              {isRegister ? 'Log in' : 'Create an account'}
            </Link>
          </p>
        </form>
      </section>
    </div>
  );
}
