import { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import api, { errorMessage, localDateKey } from '../api/client.js';
import HabitCard from '../components/HabitCard.jsx';

export default function Habits() {
  const [habits, setHabits] = useState([]);
  const [title, setTitle] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/habits', { params: { date: localDateKey() } })
      .then((res) => setHabits(res.data.habits))
      .catch((err) => setError(errorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  async function addHabit(e) {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      const { data } = await api.post('/habits', { title });
      setHabits((prev) => [...prev, data.habit]);
      setTitle('');
      setError('');
    } catch (err) {
      setError(errorMessage(err));
    }
  }

  async function toggle(habit) {
    try {
      const { data } = await api.post(`/habits/${habit.id}/toggle`, { date: localDateKey() });
      setHabits((prev) => prev.map((h) => (h.id === habit.id ? data.habit : h)));
    } catch (err) {
      setError(errorMessage(err));
    }
  }

  async function remove(habit) {
    if (!window.confirm(`Delete "${habit.title}" and its history?`)) return;
    try {
      await api.delete(`/habits/${habit.id}`);
      setHabits((prev) => prev.filter((h) => h.id !== habit.id));
    } catch (err) {
      setError(errorMessage(err));
    }
  }

  const doneToday = habits.filter((h) => h.completedToday).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Habits</h1>
        {habits.length > 0 && (
          <p className="mt-1 text-ink-soft">{doneToday} of {habits.length} done today</p>
        )}
      </div>

      <form onSubmit={addHabit} className="flex gap-2">
        <input className="field" placeholder="Read for 20 minutes" value={title} onChange={(e) => setTitle(e.target.value)} aria-label="New habit" maxLength={100} />
        <button className="btn-primary shrink-0"><Plus size={16} aria-hidden /> Add habit</button>
      </form>

      {error && <p role="alert" className="text-alert">{error}</p>}

      {loading ? (
        <p className="text-ink-soft">Loading…</p>
      ) : habits.length === 0 ? (
        <p className="panel p-6 text-ink-soft">No habits yet. Add one above, then mark it done each day to build a streak.</p>
      ) : (
        <ul className="grid gap-4 md:grid-cols-2">
          {habits.map((h) => (
            <HabitCard key={h.id} habit={h} onToggle={toggle} onDelete={remove} />
          ))}
        </ul>
      )}
    </div>
  );
}
