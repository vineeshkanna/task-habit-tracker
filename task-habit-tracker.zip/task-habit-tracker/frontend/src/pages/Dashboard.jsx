import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errorMessage, localDateKey } from '../api/client.js';

const dayLabel = (key) =>
  new Date(`${key}T12:00:00`).toLocaleDateString(undefined, { weekday: 'short' });

function Stat({ label, value, hint }) {
  return (
    <div className="panel p-5">
      <p className="text-sm text-ink-soft">{label}</p>
      <p className="mt-1 font-display text-4xl font-bold">{value}</p>
      {hint && <p className="mt-1 text-xs text-ink-faint">{hint}</p>}
    </div>
  );
}

function Meter({ label, percent }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-sm">
        <span>{label}</span>
        <span className="font-semibold">{percent}%</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-paper" role="progressbar" aria-valuenow={percent} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
        <div className="h-full rounded-full bg-pine" style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/analytics/summary', { params: { date: localDateKey() } })
      .then((res) => setData(res.data))
      .catch((err) => setError(errorMessage(err)));
  }, []);

  if (error) return <p role="alert" className="text-alert">{error}</p>;
  if (!data) return <p className="text-ink-soft">Loading…</p>;

  const { tasks, habits, daily } = data;
  const peak = Math.max(1, ...daily.map((d) => d.habitsDone + d.tasksCompleted));
  const isEmpty = tasks.total === 0 && habits.total === 0;

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">This week</h1>

      {isEmpty && (
        <div className="panel p-6 text-ink-soft">
          Nothing tracked yet. <Link className="font-semibold text-pine underline" to="/tasks">Add a task</Link> or{' '}
          <Link className="font-semibold text-pine underline" to="/habits">start a habit</Link> to see your progress here.
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Tasks completed" value={tasks.completedThisWeek} hint="last 7 days" />
        <Stat label="Open tasks" value={tasks.byStatus.PENDING + tasks.byStatus.IN_PROGRESS} hint={`${tasks.byStatus.IN_PROGRESS} in progress`} />
        <Stat label="Overdue" value={tasks.overdue} hint={tasks.overdue ? 'needs attention' : 'all caught up'} />
        <Stat label="Habits tracked" value={habits.total} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="panel space-y-5 p-6">
          <h2 className="text-lg font-semibold">Completion rates</h2>
          <Meter label="Task completion (all tasks)" percent={tasks.taskCompletionRate} />
          <Meter label="Habit fulfillment (last 7 days)" percent={habits.habitFulfillment} />
        </section>

        <section className="panel p-6">
          <h2 className="text-lg font-semibold">Daily activity</h2>
          <div className="mt-4 flex h-36 items-end gap-3">
            {daily.map((d) => {
              const total = d.habitsDone + d.tasksCompleted;
              return (
                <div key={d.date} className="flex flex-1 flex-col items-center gap-1">
                  <div className="flex w-full flex-1 flex-col justify-end overflow-hidden rounded-md bg-paper" title={`${d.tasksCompleted} tasks, ${d.habitsDone} habits`}>
                    <div className="bg-ember" style={{ height: `${(d.tasksCompleted / peak) * 100}%` }} />
                    <div className="bg-pine" style={{ height: `${(d.habitsDone / peak) * 100}%` }} />
                  </div>
                  <span className="text-[11px] text-ink-faint">{dayLabel(d.date)}</span>
                  <span className="sr-only">{total} completed</span>
                </div>
              );
            })}
          </div>
          <p className="mt-3 flex gap-4 text-xs text-ink-soft">
            <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-pine" /> Habits</span>
            <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-ember" /> Tasks</span>
          </p>
        </section>
      </div>
    </div>
  );
}
