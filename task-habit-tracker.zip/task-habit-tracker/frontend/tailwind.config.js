/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#F2F5F4',
        card: '#FFFFFF',
        ink: { DEFAULT: '#14201C', soft: '#4B5B55', faint: '#8A9892' },
        line: '#DCE3E0',
        pine: { DEFAULT: '#1F5D50', dark: '#164539', tint: '#E1EEEA' },
        ember: { DEFAULT: '#D9822B', tint: '#FBEBD8' },
        alert: '#B3402F',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'],
        sans: ['"Instrument Sans"', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
